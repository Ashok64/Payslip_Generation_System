from flask import Flask,render_template,request,flash,redirect,url_for,send_from_directory
import pandas as pd
from werkzeug.utils import secure_filename
from pathlib import Path
from docxtpl import DocxTemplate
from docx import Document
import os
import shutil

app = Flask(__name__)
base_dir = Path(__file__).parent
files_folder = base_dir/"static"/"files"
output_folder = base_dir/"static"/"output"
app.config['SECRET_KEY']="ashok"
app.config['UPLOAD_FOLDER']= files_folder

ALLOWED_EXTENSIONS = set(['xls','xlsx'])
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/exit')
def delete():
    shutil.rmtree(files_folder)
    shutil.rmtree(output_folder)
    flash("Logged out Successfully!",category="success")
    return redirect(url_for('home'))

@app.route('/download',methods=['GET','POST'])
def download():
    name = "payslip.docx"
    path = os.path.join(app.root_path,app.config['UPLOAD_FOLDER'])
    return send_from_directory(path,name)

@app.route('/',methods=['GET','POST'])
@app.route('/home',methods=['GET','POST'])
def home(): 
    return render_template('home.html')

@app.route('/teaching')
def teaching():
    return render_template('teaching.html')

@app.route('/non_teaching')
def non_teaching():
    return render_template('non-teaching.html')


@app.route('/data1',methods=['GET','POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['file']
        if file.filename == '':
            flash('No File has been Selected!',category='error')
            
        elif file and allowed_file(file.filename):
            #uploading the data
            filename = secure_filename(file.filename)
            isExists_files = os.path.exists(files_folder)
            isExists_output = os.path.exists(output_folder)
            if(isExists_files  or isExists_output):
                shutil.rmtree(files_folder)
                shutil.rmtree(output_folder)
                os.mkdir(files_folder)
                os.mkdir(output_folder)
            else:
                os.mkdir(files_folder)
                os.mkdir(output_folder)

            file.save(os.path.join(app.config['UPLOAD_FOLDER'],filename))

            #paylsip generation
            word_template_path = base_dir/"static"/"word"/"teaching.docx"
            excel_path = base_dir/"static"/"files"/filename
            output_dir = base_dir/"static"/"output"
            word_output = base_dir/"static"/"files"
            df=pd.read_excel(excel_path)
            try:
                c1=df["S.No"].values
                c2=df["Name"].values
                c3=df["Desig"].values
                c4=df["Dept"].values
                c5=df["Basic"].values
                c6=df["D.A"].values
                c7=df["H.R.A"].values
                c8=df["C.C.A"].values
                c9=df["Others"].values
                c10=df["Gross Pay"].values
                c11=df["LOP"].values
                c12=df["Salary Adv"].values
                c13=df["health Insurance"].values
                c14=df["Other deduction"]
                c15=df["Income Tax"].values
                c16=df["Prof.Tax"].values
                c17=df["Bus"].values
                c18=df["Total Deduction"].values
                c19=df["Net Pay"].values
                c20=df["Bank No"].values
            except:
                flash("Few or more column names are missing (or) Spelled incorrect",category="error")
                return redirect(url_for('teaching')) 
                

            zipped=zip(c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20)
            files = []
            for a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t in zipped:
                doc=DocxTemplate(word_template_path)
                context={"SNo":a,"Name":b,"Desig":c,"Dept":d,"Basic":e,"DA":f,"HRA":g,"CCA":h,"Others":i,"Gross_Pay":j,"LOP":k,"Salary_Adv":l,"health_Insurance":m,"Other_deduction":n,"Income_Tax":o,"Prof_Tax":p,"Bus":q,"Total_Deduction":r,"Net_Pay":s,"Bank_No":t}
                doc.render(context)
                output_path = output_dir/f"{b}.docx"
                doc.save(output_path)
                f_name = f"{b}.docx"
                files.append(f_name)

            def combine_word_documents(files):
                merged_document = Document()

                for index, file in enumerate(files):
                    path = base_dir/"static"/"output"/file
                    sub_doc = Document(path)

                    if index == len(files)-1:
                        sub_doc.add_page_break()
                    
                    for element in sub_doc.element.body:
                        merged_document.element.body.append(element)
                output_path = word_output/"payslip.docx"
                merged_document.save(output_path)
            combine_word_documents(files)
            #displaying the data
            data = pd.read_excel(file)
            return render_template('data.html',data=data.to_html())    
        else:
            flash('Allowed File Extesions are : .xls and .xlsx',category='error')
    return redirect(url_for('teaching')) 


@app.route('/data2',methods=['GET','POST'])
def upload_files():
    if request.method == 'POST':
        file = request.files['file']
        if file.filename == '':
            flash('No File has been Selected!',category='error')
            
        elif file and allowed_file(file.filename):
            #uploading the data
            filename = secure_filename(file.filename)
            isExists_files = os.path.exists(files_folder)
            isExists_output = os.path.exists(output_folder)
            if(isExists_files  or isExists_output):
                shutil.rmtree(files_folder)
                shutil.rmtree(output_folder)
                os.mkdir(files_folder)
                os.mkdir(output_folder)
            else:
                os.mkdir(files_folder)
                os.mkdir(output_folder)
                
            file.save(os.path.join(app.config['UPLOAD_FOLDER'],filename))

            #paylsip generation
            word_template_path = base_dir/"static"/"word"/"non-teaching.docx"
            excel_path = base_dir/"static"/"files"/filename
            output_dir = base_dir/"static"/"output"
            word_output = base_dir/"static"/"files"
            df=pd.read_excel(excel_path)
            try:
                c1=df["S.No"].values
                print(c1)
                c2=df["Name"].values
                c3=df["Desig"].values
                c4=df["Dept"].values
                c5=df["Basic"].values
                c6=df["D.A"].values
                c7=df["H.R.A"].values
                c8=df["C.C.A"].values
                c9=df["Others"].values
                c10=df["Gross Pay"].values
                c11=df["LOP"].values
                c12=df["Salary Adv"].values
                c13=df["Other deduction"].values
                c14=df["health Insurance"].values
                c15=df["E.P.F"].values 
                c16=df["ESI"].values
                c17=df["Prof.Tax"].values
                c18=df["Bus"].values
                c19=df["Total Deduction"].values
                c20=df["Net Pay"].values
                c21=df["Bank No"].values
            except:
                flash("Few or more columns names are missing (or) Spelled incorrect!",category="error")
                return redirect(url_for('non_teaching'))


            zipped=zip(c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20,c21)
            files = []
            for a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u in zipped:
                doc=DocxTemplate(word_template_path)
                context={"SNo":a,"Name":b,"Desig":c,"Dept":d,"Basic":e,"DA":f,"HRA":g,"CCA":h,"Others":i,"Gross_Pay":j,"LOP":k,"Salary_Adv":l,"Other_deduction":m,"health_Insurance":n,"EPF":o,"ESI":p,"Prof_Tax":q,"Bus":r,"Total_Deduction":s,"Net_Pay":t,"Bank_No":u}
                doc.render(context)
                output_path = output_dir/f"{b}.docx"
                doc.save(output_path)
                f_name = f"{b}.docx"
                files.append(f_name)

            def combine_word_documents(files):
                merged_document = Document()

                for index, file in enumerate(files):
                    path = base_dir/"static"/"output"/file
                    sub_doc = Document(path)

                    if index == len(files)-1:
                        sub_doc.add_page_break()
                    
                    for element in sub_doc.element.body:
                        merged_document.element.body.append(element)
                output_path = word_output/"payslip.docx"
                merged_document.save(output_path)
            combine_word_documents(files)
            #displaying the data
            data = pd.read_excel(file)
            return render_template('data.html',data=data.to_html())    
        else:
            flash('Allowed File Extesions are : .xls and .xlsx',category='error')
    return redirect(url_for('non_teaching'))
    
if __name__ == "__main__":
    app.run(debug=True)